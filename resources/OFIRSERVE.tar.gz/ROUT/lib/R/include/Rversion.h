/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 197377
#define R_NICK "Bug in Your Hair"
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "3"
#define R_MINOR  "3.1"
#define R_STATUS ""
#define R_YEAR   "2016"
#define R_MONTH  "06"
#define R_DAY    "21"
#define R_SVN_REVISION 70800
#define R_FILEVERSION    3,31,70800,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
